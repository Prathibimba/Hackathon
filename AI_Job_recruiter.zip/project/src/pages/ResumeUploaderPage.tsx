import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Trash2 } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

interface ParsedResume {
  personalInfo: {
    name: string;
    email: string;
    phone?: string;
    location?: string;
  };
  education: {
    degree: string;
    institution: string;
    year: string;
  }[];
  experience: {
    title: string;
    company: string;
    duration: string;
    highlights: string[];
  }[];
  skills: string[];
  description: string;
}

export default function ResumeUploaderPage() {
  const [isParsing, setIsParsing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [parsedResume, setParsedResume] = useState<ParsedResume | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [description, setDescription] = useState('');

  const onDrop = React.useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    setUploadedFile(file);
    await parseResume(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    multiple: false
  });

  const parseResume = async (file: File) => {
    setIsParsing(true);
    setError(null);

    try {
      // Simulated API call for resume parsing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setParsedResume({
        personalInfo: {
          name: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1 (555) 123-4567',
          location: 'San Francisco, CA'
        },
        education: [
          {
            degree: 'Master of Science in Computer Science',
            institution: 'Stanford University',
            year: '2020'
          },
          {
            degree: 'Bachelor of Engineering in Software Engineering',
            institution: 'University of California, Berkeley',
            year: '2018'
          }
        ],
        experience: [
          {
            title: 'Senior Software Engineer',
            company: 'Tech Corp',
            duration: '2020 - Present',
            highlights: [
              'Led development of microservices architecture',
              'Managed team of 5 developers',
              'Reduced system latency by 40%'
            ]
          },
          {
            title: 'Software Engineer',
            company: 'StartUp Inc',
            duration: '2018 - 2020',
            highlights: [
              'Developed full-stack web applications',
              'Implemented CI/CD pipeline',
              'Improved test coverage to 90%'
            ]
          }
        ],
        skills: [
          'JavaScript',
          'TypeScript',
          'React',
          'Node.js',
          'Python',
          'AWS',
          'Docker',
          'Kubernetes'
        ],
        description: description
      });
    } catch (err) {
      setError('Failed to parse resume. Please try again.');
      setParsedResume(null);
    } finally {
      setIsParsing(false);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    setParsedResume(null);
    setError(null);
    setDescription('');
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Resume Upload & Analysis</h1>
        <p className="mt-2 text-gray-600">
          Upload your resume to automatically extract your experience, skills, and qualifications.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          {/* Upload Section */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div {...getRootProps()} className={`mb-4 ${uploadedFile ? 'hidden' : ''}`}>
              <input {...getInputProps()} />
              <div className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300 hover:border-indigo-400'
              }`}>
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Drag & drop your resume, or click to select
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Supports PDF, DOC, DOCX
                </p>
              </div>
            </div>

            {uploadedFile && (
              <>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg mb-4">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-6 w-6 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{uploadedFile.name}</p>
                      <p className="text-xs text-gray-500">
                        {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={removeFile}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-2">
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                    Additional Notes
                  </label>
                  <textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Add any additional information or notes about your resume..."
                    className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                  <button
                    onClick={() => parseResume(uploadedFile)}
                    className="w-full mt-4 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                  >
                    Analyze Resume
                  </button>
                </div>
              </>
            )}

            {error && (
              <div className="mt-4 flex items-center gap-2 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}

            {isParsing && (
              <div className="mt-4 text-center">
                <div className="animate-pulse text-indigo-600">Analyzing resume...</div>
              </div>
            )}
          </div>
        </div>

        {/* Parsed Results */}
        {parsedResume && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="space-y-6">
                {/* Personal Information */}
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">
                    Personal Information
                  </h2>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Name</p>
                      <p className="font-medium">{parsedResume.personalInfo.name}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-medium">{parsedResume.personalInfo.email}</p>
                    </div>
                    {parsedResume.personalInfo.phone && (
                      <div className="space-y-1">
                        <p className="text-sm text-gray-500">Phone</p>
                        <p className="font-medium">{parsedResume.personalInfo.phone}</p>
                      </div>
                    )}
                    {parsedResume.personalInfo.location && (
                      <div className="space-y-1">
                        <p className="text-sm text-gray-500">Location</p>
                        <p className="font-medium">{parsedResume.personalInfo.location}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Additional Notes */}
                {description && (
                  <div>
                    <h3 className="font-medium text-gray-900 mb-3">Additional Notes</h3>
                    <p className="text-gray-600 bg-gray-50 p-4 rounded-md">{description}</p>
                  </div>
                )}

                {/* Skills */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {parsedResume.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-indigo-100 text-indigo-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Experience */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Experience</h3>
                  <div className="space-y-4">
                    {parsedResume.experience.map((exp, index) => (
                      <div key={index} className="border-l-2 border-indigo-200 pl-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium text-gray-900">{exp.title}</p>
                            <p className="text-sm text-gray-600">{exp.company}</p>
                          </div>
                          <span className="text-sm text-gray-500">{exp.duration}</span>
                        </div>
                        <ul className="mt-2 list-disc list-inside text-sm text-gray-600">
                          {exp.highlights.map((highlight, idx) => (
                            <li key={idx}>{highlight}</li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Education */}
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Education</h3>
                  <div className="space-y-4">
                    {parsedResume.education.map((edu, index) => (
                      <div key={index} className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-gray-900">{edu.degree}</p>
                          <p className="text-sm text-gray-600">{edu.institution}</p>
                        </div>
                        <span className="text-sm text-gray-500">{edu.year}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}