import React, { useState } from 'react';
import {
  Search,
  Filter,
  ChevronDown,
  Star,
  StarOff,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Download,
} from 'lucide-react';

interface Candidate {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  experience: string;
  skills: string[];
  matchScore: number;
  status: 'new' | 'shortlisted' | 'rejected';
  appliedDate: string;
  starred: boolean;
}

const mockCandidates: Candidate[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah.j@example.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    experience: '5 years',
    skills: ['React', 'Node.js', 'TypeScript', 'AWS'],
    matchScore: 92,
    status: 'new',
    appliedDate: '2024-03-15',
    starred: false,
  },
  {
    id: '2',
    name: 'Michael Chen',
    email: 'michael.c@example.com',
    phone: '+1 (555) 987-6543',
    location: 'New York, NY',
    experience: '7 years',
    skills: ['Python', 'Django', 'PostgreSQL', 'Docker'],
    matchScore: 88,
    status: 'shortlisted',
    appliedDate: '2024-03-14',
    starred: true,
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.r@example.com',
    phone: '+1 (555) 456-7890',
    location: 'Austin, TX',
    experience: '3 years',
    skills: ['Vue.js', 'Express', 'MongoDB', 'Git'],
    matchScore: 85,
    status: 'new',
    appliedDate: '2024-03-13',
    starred: false,
  },
];

export default function CandidatesPage() {
  const [candidates, setCandidates] = useState<Candidate[]>(mockCandidates);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const toggleStar = (candidateId: string) => {
    setCandidates(candidates.map(candidate =>
      candidate.id === candidateId
        ? { ...candidate, starred: !candidate.starred }
        : candidate
    ));
  };

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterStatus === 'all' || candidate.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Candidates</h1>
        <p className="mt-2 text-gray-600">
          View and manage all job applicants in one place.
        </p>
      </div>

      {/* Search and Filter Bar */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search candidates or skills..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
        </div>
        <div className="flex gap-4">
          <div className="relative">
            <button
              className="px-4 py-2 border border-gray-300 rounded-lg inline-flex items-center gap-2 hover:bg-gray-50"
            >
              <Filter className="h-5 w-5 text-gray-400" />
              Filter
              <ChevronDown className="h-4 w-4 text-gray-400" />
            </button>
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg bg-white"
          >
            <option value="all">All Status</option>
            <option value="new">New</option>
            <option value="shortlisted">Shortlisted</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Candidates List */}
      <div className="bg-white rounded-lg shadow">
        <div className="divide-y divide-gray-200">
          {filteredCandidates.map((candidate) => (
            <div key={candidate.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {candidate.name}
                    </h3>
                    <button
                      onClick={() => toggleStar(candidate.id)}
                      className="text-gray-400 hover:text-yellow-400"
                    >
                      {candidate.starred ? (
                        <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      ) : (
                        <StarOff className="h-5 w-5" />
                      )}
                    </button>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      candidate.status === 'shortlisted'
                        ? 'bg-green-100 text-green-800'
                        : candidate.status === 'rejected'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {candidate.status.charAt(0).toUpperCase() + candidate.status.slice(1)}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center gap-6 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      {candidate.email}
                    </div>
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      {candidate.phone}
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {candidate.location}
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex flex-wrap gap-2">
                      {candidate.skills.map((skill, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="ml-6 flex flex-col items-end">
                  <div className="text-2xl font-bold text-indigo-600">
                    {candidate.matchScore}%
                  </div>
                  <div className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                    <Calendar className="h-4 w-4" />
                    Applied {new Date(candidate.appliedDate).toLocaleDateString()}
                  </div>
                  <button className="mt-4 flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-500">
                    <Download className="h-4 w-4" />
                    Download Resume
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}