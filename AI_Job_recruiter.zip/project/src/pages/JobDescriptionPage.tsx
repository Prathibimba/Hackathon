import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

interface AnalyzedSkill {
  name: string;
  importance: 'required' | 'preferred';
  category: 'technical' | 'soft' | 'domain';
}

interface AnalysisResult {
  title: string;
  department: string;
  experience: string;
  skills: AnalyzedSkill[];
  responsibilities: string[];
  qualifications: string[];
}

export default function JobDescriptionPage() {
  const [jobDescription, setJobDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onDrop = React.useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    const reader = new FileReader();
    reader.onload = () => {
      setJobDescription(reader.result as string);
    };
    reader.readAsText(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    multiple: false
  });

  const analyzeJobDescription = async () => {
    if (!jobDescription.trim()) {
      setError('Please enter or upload a job description');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      // Simulated analysis result for now
      // This will be replaced with actual API call later
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setAnalysisResult({
        title: 'Senior Software Engineer',
        department: 'Engineering',
        experience: '5+ years',
        skills: [
          { name: 'React', importance: 'required', category: 'technical' },
          { name: 'Node.js', importance: 'required', category: 'technical' },
          { name: 'TypeScript', importance: 'required', category: 'technical' },
          { name: 'Team Leadership', importance: 'preferred', category: 'soft' },
          { name: 'System Design', importance: 'required', category: 'domain' },
        ],
        responsibilities: [
          'Lead development of complex web applications',
          'Mentor junior developers',
          'Architect scalable solutions',
          'Code review and quality assurance',
        ],
        qualifications: [
          'Bachelor\'s degree in Computer Science or related field',
          '5+ years of experience in web development',
          'Strong understanding of software design patterns',
          'Experience with cloud platforms (AWS/Azure/GCP)',
        ],
      });
    } catch (err) {
      setError('Failed to analyze job description. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Job Description Analyzer</h1>
        <p className="mt-2 text-gray-600">
          Upload or paste your job description to get an AI-powered analysis of key requirements and skills.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          {/* Input Section */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div {...getRootProps()} className="mb-4">
              <input {...getInputProps()} />
              <div className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300 hover:border-indigo-400'
              }`}>
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Drag & drop a job description file, or click to select
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Supports TXT, PDF, DOC, DOCX
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <textarea
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                placeholder="Or paste your job description here..."
                className="w-full h-64 px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
              />
              
              {error && (
                <div className="flex items-center gap-2 text-red-600 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span>{error}</span>
                </div>
              )}

              <button
                onClick={analyzeJobDescription}
                disabled={isAnalyzing}
                className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FileText className="h-5 w-5" />
                {isAnalyzing ? 'Analyzing...' : 'Analyze Description'}
              </button>
            </div>
          </div>
        </div>

        {/* Analysis Results */}
        <div className="space-y-6">
          {analysisResult && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Analysis Results</h2>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Position Title</p>
                      <p className="font-medium">{analysisResult.title}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Department</p>
                      <p className="font-medium">{analysisResult.department}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-gray-500">Experience Level</p>
                      <p className="font-medium">{analysisResult.experience}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Required Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.skills.map((skill, index) => (
                      <span
                        key={index}
                        className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                          skill.importance === 'required'
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {skill.name}
                        {skill.importance === 'required' && (
                          <CheckCircle className="ml-1 h-4 w-4 text-indigo-600" />
                        )}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Key Responsibilities</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {analysisResult.responsibilities.map((responsibility, index) => (
                      <li key={index}>{responsibility}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Qualifications</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {analysisResult.qualifications.map((qualification, index) => (
                      <li key={index}>{qualification}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}