import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  User,
  Video,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Plus,
} from 'lucide-react';

interface Interview {
  id: string;
  candidateName: string;
  position: string;
  date: string;
  time: string;
  duration: string;
  type: 'video' | 'in-person';
  location: string;
  status: 'scheduled' | 'completed' | 'cancelled';
}

const mockInterviews: Interview[] = [
  {
    id: '1',
    candidateName: 'Sarah Johnson',
    position: 'Senior Software Engineer',
    date: '2024-03-20',
    time: '10:00 AM',
    duration: '1 hour',
    type: 'video',
    location: 'Google Meet',
    status: 'scheduled',
  },
  {
    id: '2',
    candidateName: 'Michael Chen',
    position: 'Full Stack Developer',
    date: '2024-03-20',
    time: '2:00 PM',
    duration: '45 minutes',
    type: 'in-person',
    location: 'Office - Room 3A',
    status: 'scheduled',
  },
  {
    id: '3',
    candidateName: 'Emily Rodriguez',
    position: 'Frontend Developer',
    date: '2024-03-19',
    time: '11:30 AM',
    duration: '1 hour',
    type: 'video',
    location: 'Zoom',
    status: 'completed',
  },
];

export default function InterviewsPage() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [interviews, setInterviews] = useState<Interview[]>(mockInterviews);

  const navigateMonth = (direction: 'prev' | 'next') => {
    setSelectedDate(new Date(selectedDate.setMonth(
      selectedDate.getMonth() + (direction === 'next' ? 1 : -1)
    )));
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Interview Schedule</h1>
          <p className="mt-2 text-gray-600">
            Manage and track all upcoming interviews.
          </p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
          <Plus className="h-5 w-5" />
          Schedule Interview
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-7 gap-8">
        {/* Calendar */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">
              {selectedDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
            </h2>
            <div className="flex gap-2">
              <button
                onClick={() => navigateMonth('prev')}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <ChevronLeft className="h-5 w-5 text-gray-500" />
              </button>
              <button
                onClick={() => navigateMonth('next')}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <ChevronRight className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-7 gap-1 text-center text-sm mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="text-gray-500 font-medium py-1">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1 text-sm">
            {Array.from({ length: 35 }, (_, i) => i + 1).map(day => (
              <button
                key={day}
                className={`py-2 rounded-lg hover:bg-gray-50 ${
                  day === selectedDate.getDate()
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'text-gray-700'
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>

        {/* Interviews List */}
        <div className="lg:col-span-5 space-y-6">
          {interviews.map(interview => (
            <div
              key={interview.id}
              className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5 text-gray-400" />
                    <h3 className="text-lg font-semibold text-gray-900">
                      {interview.candidateName}
                    </h3>
                    <span className={`px-3 py-1 rounded-full text-sm ${
                      interview.status === 'completed'
                        ? 'bg-green-100 text-green-800'
                        : interview.status === 'cancelled'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {interview.status.charAt(0).toUpperCase() + interview.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-gray-600">{interview.position}</p>
                  <div className="flex items-center gap-6 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {new Date(interview.date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {interview.time} ({interview.duration})
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    {interview.type === 'video' ? (
                      <Video className="h-4 w-4" />
                    ) : (
                      <MapPin className="h-4 w-4" />
                    )}
                    {interview.location}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="px-4 py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg">
                    View Details
                  </button>
                  <button className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 rounded-lg">
                    Reschedule
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}